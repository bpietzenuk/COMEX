## This step will remove the reads which are mapping across different transposable element families.
## You need a refference annotation file for example see "Alyrata_RepMaskedMerged_annoatation.txt"
# and "outputfile1_multiplemapped_reads.sam" genrated from previous output
## output file name can given at commond line ### see README file
import sys

def isInRange(start, end, ranges):
    for s, e in ranges:
        if s <= start and end <= e:
            return True
    return False


dic = {}

families = {}

#file1 = open("path/filename")  ## location of TE annotation file
file1 = open(sys.argv[2])  ## location of TE annotation file
for line1 in file1:
    splits = line1.split("\t")
    if line1 != "\n":
        name = splits[4].strip()
        start = int(splits[1].strip())
        end = int(splits[2].strip())
        if name not in families:
            families[name] = [(start, end)]
        else:
            families[name].append((start, end))

#file2 = open("path/filename.sam")  ## Inputfile containing multiple-mapping reads from previous step in .sam-format
file2 = open(sys.argv[1])  ## Inputfile containing multiple-mapping reads from previous step in .sam-format
for line2 in file2:
    splits2 = line2.split("\t")
    if line2 != "\n":
        start2 = int(splits2[3].strip())
        end2 = int(splits2[len(splits2) - 1].strip())
        #		end2=int(splits2[4].strip())
        id2 = splits2[0].strip() + "\t" + splits2[3].strip()
        for name in families:
            ranges = families[name]
            if isInRange(start2, end2, ranges):
                if id2 not in dic:
                    dic[id2] = [name]
                else:
                    dic[id2].append(name)

#file2 = open("path/filename.sam")  ## Inputfile containing multiple-mapping reads from previous step in .sam-format
file2 = open(sys.argv[1])  ## Inputfile containing multiple-mapping reads from previous step in .sam-format
for line2 in file2:
    splits2 = line2.split("\t")
    if line2 != "\n":
        id2 = splits2[0].strip() + "\t" + splits2[3].strip()
        if id2 in dic and len(dic[id2]) == 1:
            print line2.strip()
