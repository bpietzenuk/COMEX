file = open("Alyrata_RepMaskedMerged_annoatation_out.txt")
dic={}
for line in file:
	if line != '\n':
		splits=line.split('\t')
		if float(splits[11].strip())>=0.55:
			check=splits[5].strip()+"\t"+splits[4].strip()
			if check not in dic:
				dic[check]=splits[12].strip()+"\t"+splits[13].strip()+"\t"+splits[14].strip()+"\t"+splits[15].strip()+"\t"+splits[16].strip()+"\t"+splits[17].strip()+"\t"+splits[18].strip()+"\t"+splits[19].strip()

for key in dic:
	print key ,"\t", dic[key]






 


