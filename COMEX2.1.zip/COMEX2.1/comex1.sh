#!/bin/bash

echo "Please enter the name of bam input file: "
read InputBam
if [ -f $InputBam ];
then
   echo "File $InputBam exists."
else
   echo "File $InputBam does not exist."
exit
fi
#echo $InputBam
# set Internal_Field_Separator(IFS) to \. to remove .bam from end of filename
IFS=\.
arr=($InputBam)
input=${arr[0]}
#echo $input
# restore the default IFS
IFS=$OIFS
echo "Please enter the name of TE annotation file: "
read annotation;
if [ -f $annotation ];
then
   echo "File $annotation exists."
else
   echo "File $annotation does not exist."
exit
fi
echo "Please enter the name of reference genome file: "
read referenceGenome;
if [ -f $referenceGenome ];
then
   echo "File $referenceGenome exists."
else
   echo "File $referenceGenome does not exist."
exit
fi
#echo $annotation
#echo $referenceGenome

samtools view -h $InputBam >$input'.sam'

python toprintend1.py $input'.sam' $input'_end.sam'

python Selectnonrepeated1.py $input'_end.sam' $input'_hits_nonrepeated.sam'

python Selectmultiplemap1.py $input'_hits_nonrepeated.sam' $input'_multiplemapped_reads.sam' $input'_uniquelymapped_reads.sam'

python new_cases1.py $input'_multiplemapped_reads.sam' $annotation >$input'_multiplecorrected.sam'

cat $input'_multiplecorrected.sam' $input'_uniquelymapped_reads.sam' >$input'_merged.sam'

python removeEnd1.py $input'_merged.sam' >$input'_output_final.sam'

samtools view -bT $referenceGenome $input'_output_final.sam' >$input'outfile.bam'

