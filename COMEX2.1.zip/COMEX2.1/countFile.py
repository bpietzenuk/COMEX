## additional output containing number of TEs expressed above and below defined threshold value and their average length etc

def makedic(file):
	Dic={}
	for line in open(file):
		splits=line.split("\t")
		ar=float(splits[11].strip())
		if splits[4].strip()+"\t"+splits[5].strip() not in Dic:
			if ar >= 0.55: ## threshold value (i.e. 0.55)
				Dic[splits[4].strip()+"\t"+splits[5].strip()] =[splits[5].strip(),1,1,float(splits[3].strip()),float(splits[11].strip()), float(splits[7].strip()),float(splits[9].strip()),0,0,0,0,0]
			elif ar < 0.55: ## threshold value (i.e. 0.55)
				Dic[splits[4].strip()+"\t"+splits[5].strip()] =[splits[5].strip(),1,0,0,0,0,0,1,float(splits[3].strip()),float(splits[11].strip()), float(splits[7].strip()),float(splits[9].strip())]
		elif splits[4].strip()+"\t"+splits[5].strip() in Dic:
			if ar >= 0.55: ## threshold value (i.e. 0.55)
				Dic[splits[4].strip()+"\t"+splits[5].strip()][1]=Dic[splits[4].strip()+"\t"+splits[5].strip()][1]+1 ## total copy number
				Dic[splits[4].strip()+"\t"+splits[5].strip()][2]=Dic[splits[4].strip()+"\t"+splits[5].strip()][2]+1 ## total expressed
				Dic[splits[4].strip()+"\t"+splits[5].strip()][3]=Dic[splits[4].strip()+"\t"+splits[5].strip()][3]+float(splits[3].strip()) # total length
				Dic[splits[4].strip()+"\t"+splits[5].strip()][4]=Dic[splits[4].strip()+"\t"+splits[5].strip()][4]+float(splits[11].strip()) # total rpkm
				Dic[splits[4].strip()+"\t"+splits[5].strip()][5]=Dic[splits[4].strip()+"\t"+splits[5].strip()][5]+float(splits[7].strip()) # total rc1
				Dic[splits[4].strip()+"\t"+splits[5].strip()][6]=Dic[splits[4].strip()+"\t"+splits[5].strip()][6]+float(splits[9].strip()) # total rc2
			elif ar < 0.55: ## threshold value (i.e. 0.55)
				Dic[splits[4].strip()+"\t"+splits[5].strip()][1]=Dic[splits[4].strip()+"\t"+splits[5].strip()][1]+1 ## total copy number expressed
				Dic[splits[4].strip()+"\t"+splits[5].strip()][7]=Dic[splits[4].strip()+"\t"+splits[5].strip()][7]+1 ## total copy number not expressed
				Dic[splits[4].strip()+"\t"+splits[5].strip()][8]=Dic[splits[4].strip()+"\t"+splits[5].strip()][8]+float(splits[3].strip()) # total not expressed length
				Dic[splits[4].strip()+"\t"+splits[5].strip()][9]=Dic[splits[4].strip()+"\t"+splits[5].strip()][9]+float(splits[11].strip()) # total not expressed rpkm
				Dic[splits[4].strip()+"\t"+splits[5].strip()][10]=Dic[splits[4].strip()+"\t"+splits[5].strip()][10]+float(splits[7].strip()) # total not expressed c1
				Dic[splits[4].strip()+"\t"+splits[5].strip()][11]=Dic[splits[4].strip()+"\t"+splits[5].strip()][11]+float(splits[9].strip()) # total not expressed c2
	return Dic
	
## can we change LyrataDic and ThalDic to more general? (NAVRATAN?)	see also later?
LyrataDic=makedic("filename species A") ## Input file species A containing all values of differential expression from previous steps 
ThalDic= makedic("filename species B")  ## Input file species B containing all values of differential expression from previous steps


for subfam in LyrataDic:
	if	subfam in ThalDic:
		print subfam,"\t",LyrataDic[subfam][1],"\t",LyrataDic[subfam][2],"\t",LyrataDic[subfam][3],"\t",LyrataDic[subfam][4],"\t",LyrataDic[subfam][5],"\t",LyrataDic[subfam][6],"\t",LyrataDic[subfam][7],"\t",LyrataDic[subfam][8],"\t",LyrataDic[subfam][9],"\t",LyrataDic[subfam][10],"\t",LyrataDic[subfam][11],"\t","\t",ThalDic[subfam][1],"\t",ThalDic[subfam][2],"\t",ThalDic[subfam][3],"\t",ThalDic[subfam][4],"\t",ThalDic[subfam][5],"\t",ThalDic[subfam][6],"\t",ThalDic[subfam][7],"\t",ThalDic[subfam][8],"\t",ThalDic[subfam][9],"\t",ThalDic[subfam][10],"\t",ThalDic[subfam][11]
	elif subfam not in ThalDic:
		print subfam,"\t",LyrataDic[subfam][1],"\t",LyrataDic[subfam][2],"\t",LyrataDic[subfam][3],"\t",LyrataDic[subfam][4],"\t",LyrataDic[subfam][5],"\t",LyrataDic[subfam][6],"\t",LyrataDic[subfam][7],"\t",LyrataDic[subfam][8],"\t",LyrataDic[subfam][9],"\t",LyrataDic[subfam][10],"\t",LyrataDic[subfam][11],"\t","\t",0,"\t",0,"\t",0,"\t",0,"\t",0,"\t",0,"\t",0,"\t",0,"\t",0,"\t",0,"\t",0

for sfams in ThalDic:
	if sfams not in LyrataDic:
		print sfams,"\t",0,"\t",0,"\t",0,"\t",0,"\t",0,"\t",0,"\t",0,"\t",0,"\t",0,"\t",0,"\t",0,"\t","\t",ThalDic[sfams][1],"\t",ThalDic[sfams][2],"\t",ThalDic[sfams][3],"\t",ThalDic[sfams][4],"\t",ThalDic[sfams][5],"\t",ThalDic[sfams][6],"\t",ThalDic[sfams][7],"\t",ThalDic[sfams][8],"\t",ThalDic[sfams][9],"\t",ThalDic[sfams][10],"\t",ThalDic[sfams][11]
