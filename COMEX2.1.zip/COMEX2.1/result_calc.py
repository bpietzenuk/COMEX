## Summarizes individual TEs and values to family level. Output file contains summed data and averaged values of TEs per family.

file1 = open("filename")  ## Inputfile containing RPKM values for individual TEs

# file1=open("grp.txt") <- dunno what is this?!? Navratan???
maindic = {}  ## for major family
for line in file1:
    if line != '\n':
        splits = line.split('\t')
        if splits[5].strip() not in maindic:  # key= major family
            maindic[splits[5].strip()] = [line.strip()]
        elif splits[5].strip() in maindic:
            maindic[splits[5].strip()].append(line.strip())

finaldic = {}  # final dic of expressed ones
for i2 in maindic:
    subdic = {}  ##for minor family
    for j in maindic[i2]:
        split1 = j.split('\t')
        if split1[4].strip() not in subdic:  # key= minor family
            subdic[split1[4].strip()] = [j]
        elif split1[4].strip() in subdic:
            subdic[split1[4].strip()].append(j)
    for j2 in subdic:  # iterate through subfamily of one of the major family
        index = 11  # index of average rpkm
        rpm = 0.0  # to add all rpm
        count = 0  # to count number of entries
        sums = 0.0  # give average of average rpm of expressed TEs
        readavg1 = 0.0  # gives total read count of expressed ones of sample 1
        readavg2 = 0.0  # gives total read count of expressed ones of sample 2
        length = 0.0  # total length of expressed ones
        total = 0.0  # total length of expressed ones
        read1 = 0.0  # gives total read count of expressed ones of sample 1
        read2 = 0.0  # gives total read count of expressed ones of sample 2
        rm = list()  # create list of all the entries have average rpkm >0
        for m in subdic[j2]:
            split2 = m.split('\t')
            if float(split2[index].strip()) > 0.0:  # if average rpkm is >0
                rm.append(float(split2[index].strip()))
            if float(split2[
                         index].strip()) >= 0.55:  # if average rpkm is >0.55 i.e expressed TEs (value can be changed to individual needs)
                read1 = read1 + int(split2[7].strip())  # count the read
                read2 = read2 + int(split2[9].strip())  # count the read
                rpm = rpm + float(split2[index].strip())  # add the average rpm of expressed TE families
                length = length + float(split2[3].strip())  # add length
                #					print int(split2[10].strip())
                count = count + 1.0  # counts how many TEs are expressed within individual families (RPKM > 0.55)
        rm.sort()
        if rpm != 0:
            sums = rpm / count  ## following lines
        #			if read1!=0:
        #				readavg1=read1/count
        #			if read2!=0:
        #				readavg2=read2/count
        #			if length!=0:
        #				total=total+(length/count)
        readavg1 = read1  # total read count of sample 1
        readavg2 = read2  # total read count of sample 2
        total = length  # total length of expressed
        for m2 in subdic[j2]:
            split3 = m2.split('\t')
            k = split3[6].strip()  # unique ids
            if k not in finaldic:
                finaldic[k] = split3[0:12]  # add all columns to final dic for the unique ids +1
            if float(split3[index].strip()) >= 0.55:  # if values is >0.55 (values can be changed to own needs)
                rm.sort()
                mn = rm[0]  # min rpm
                mx = rm[len(rm) - 1]  # max rpm
                finaldic[k].append(sums)  # average of average rpm
                finaldic[k].append(count)  # total expressed
                finaldic[k].append(total)  # total length of expressed
                finaldic[k].append(len(subdic[j2]))  # total entries of the subfamily
                finaldic[k].append(mn)  # min rpm
                finaldic[k].append(mx)  # max rpm
                finaldic[k].append(readavg1)  # total readcount of sample 1
                finaldic[k].append(readavg2)  # total read count of sample 2
            else:
                finaldic[k].append(0.0)

for e in finaldic:
    l = finaldic[e][0]
    for e1 in range(1, len(finaldic[e])):
        l = l + '\t' + str(finaldic[e][e1])
    print l
