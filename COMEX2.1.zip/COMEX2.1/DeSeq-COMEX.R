http://cartwrightlab.wikispaces.com/DESeq

Command Line in R

source("http://bioconductor.org/biocLite.R")

biocLite("DESeq")

library("DESeq")

count_table<- read.table("input.txt", header=T,row.names=1)

head(count_table)

conds<-factor(c("a","a","b","b"))

library("DESeq")

cds<-newCountDataSet(count_table,conds)

head(counts(cds))

cds<-estimateSizeFactors(cds)

sizeFactors(cds)

cds<-estimateDispersions(cds,fitType="local")

res<-nbinomTest(cds, "a","b")

write.csv(res, "outputname.txt")