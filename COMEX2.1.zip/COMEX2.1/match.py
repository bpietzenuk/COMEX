## combines Data on TE family level of two species with each other!


file = open("filename")  ## input file species A (table) (A.thaliana)
dic_AT = {}
for line in file:
    if line != '\n':
        splits = line.split('\t')
        k = splits[0].strip() + "\t" + splits[1].strip()
        dic_AT[k] = line.strip()

file2 = open("filename")  ## Input file species B (table)(A. lyrata)
dic_AL = {}
for line2 in file2:
    if line2 != '\n':
        splits2 = line2.split('\t')
        check = splits2[0].strip() + "\t" + splits2[1].strip()
        dic_AL[check] = line2.strip()
        if check in dic_AT:
            print dic_AT[check], "\t", line2.strip()

print "\n"
print "\n"
print "\n"
print "Specific Entries in species A"  ## header for list of entries which are exclusively in species A
print "\n"
print "\n"

for i1 in dic_AT:
    if i1 not in dic_AL:
        print dic_AT[
            i1], "\t", "NOT IN Species B"  ## header for list of entries which are NOT in species B (not in species A)

print "\n"
print "\n"
print "\n"
print "Specific Entries in Species B"  ## header for list of entries which are exclusively in species B
print "\n"
print "\n"

for i2 in dic_AL:
    if i2 not in dic_AT:
        p = "" + "\t"
        print "NOT IN Species A", p * 9, "\t", dic_AL[
            i2]  ## header for list of entries which are NOT in species A (not in species B)
