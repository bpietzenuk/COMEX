# gives two outfiles. One containing multiple-mapping reads and one that contains only single-mapping reads.
# this program splits the .sam file into two files
#input of this program is form output of "Selectnonrepeated.py"
import sys

file_o1 = open(sys.argv[2], 'w')  ## outputfile in .sam-format containing only multiple mapped reads 'outputfile1_multiplemapped_reads.sam'
file_o2 = open(sys.argv[3], 'w')  ## outputfile in .sam-format containing only single mapped reads 'outputfile2_single_mapping_reads.sam'

file1 = open(sys.argv[1]) # input file name like path/accepted_hits_nonrepeated.sam
length = 0
dic = {}
for line in file1:
    if line != "\n":
        start = 0
        end = 0
        splits = line.split('\t')
        length = len(splits)
        check = "LOL"
        while check != "NH":
            length = length - 1
            rep = splits[length].strip()
            repL = rep.split(":")
            check = repL[0]
        if int(repL[2]) > 1:
            ln1 = [line.strip(), '\n']
            file_o1.writelines(ln1)
        else:
            ln2 = [line.strip(), '\n']
            file_o2.writelines(ln2)

file_o1.close()
file_o2.close()
